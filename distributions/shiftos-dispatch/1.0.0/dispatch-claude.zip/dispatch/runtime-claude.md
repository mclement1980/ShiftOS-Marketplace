# DISPATCH — Claude Route

## Supported model

- Preferred: Claude Opus 4.8
- Minimum: Claude Sonnet 5
- Effort: use the runtime default; do not lower it for speed

If the current session is below Sonnet 5 or the model cannot be verified, stop before Bootstrap. Relaunch on Opus 4.8 or Sonnet 5, then invoke `/dispatch`.

Heavy Alternatives, brief, deliverable, and verification subagents must use Opus 4.8 or Sonnet 5. Prefer Opus 4.8 for complex, multi-file, audience-facing, sensitive, or high-risk work.

## Install

Place the `dispatch` folder in the active Claude skills directory:

```text
~/.claude/skills/dispatch/
```

The folder must contain `SKILL.md`, `README.md`, and `references/`.

Restart or refresh skill discovery if the runtime does not immediately show `/dispatch`.

## Invoke

```text
/dispatch
```

or ask Claude to “run DISPATCH.”

## Verify

Confirm:

1. `/dispatch` is discoverable.
2. The model gate appears before project selection.
3. The gate recommends Opus 4.8 and refuses anything below Sonnet 5.
4. The Bootstrap asks Start from scratch or Evaluate an existing project.

## Remove

Remove only `~/.claude/skills/dispatch/`. Existing `dispatch-brief.md`, deliverables, and `dispatch-debrief.md` files remain untouched.

