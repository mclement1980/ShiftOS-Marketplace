# DISPATCH — Codex Route

## Supported model

- Preferred default: `gpt-5.6-sol` at medium reasoning
- Complex, multi-file, audience-facing, sensitive, or high-risk work: `gpt-5.6-sol` at high reasoning
- Minimum fallback for bounded, low-risk, single-artifact work: `gpt-5.6-terra` at high reasoning

If the current session is below the floor or the model cannot be verified, stop before Bootstrap. Relaunch with a supported model and reasoning level, then invoke `/dispatch`.

Heavy Alternatives, brief, deliverable, and verification subagents must meet the same floor. Do not use lightweight or mini models.

## Install

Place the `dispatch` folder in the active Codex skills directory:

```text
~/.codex/skills/dispatch/
```

The folder must contain `SKILL.md`, `README.md`, and `references/`.

Restart or refresh skill discovery if the runtime does not immediately show `dispatch`.

## Invoke

```text
/dispatch
```

or ask Codex to “run DISPATCH.”

## Verify

Confirm:

1. DISPATCH is discoverable.
2. The model gate appears before project selection.
3. The gate recommends `gpt-5.6-sol` at medium reasoning.
4. The Bootstrap asks Start from scratch or Evaluate an existing project.

## Remove

Remove only `~/.codex/skills/dispatch/`. Existing `dispatch-brief.md`, deliverables, and `dispatch-debrief.md` files remain untouched.

